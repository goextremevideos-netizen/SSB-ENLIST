import crypto from "node:crypto";

function cookies(req) {
  const raw=req.headers.get("cookie")||"";
  return Object.fromEntries(raw.split(";").map(v=>v.trim()).filter(Boolean).map(v=>{
    const i=v.indexOf("="); return [v.slice(0,i),decodeURIComponent(v.slice(i+1))];
  }));
}
function verify(token,secret){
  if(!token) return null;
  const [body,sig]=token.split(".");
  if(!body||!sig) return null;
  const expected=crypto.createHmac("sha256",secret).update(body).digest("base64url");
  const a=Buffer.from(sig), b=Buffer.from(expected);
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return null;
  const p=JSON.parse(Buffer.from(body,"base64url").toString());
  if(!p.exp || Date.now()>p.exp) return null;
  return p;
}

export default async (req) => {
  const secret=process.env.DISCORD_CLIENT_SECRET;
  if(!secret) return Response.json({error:"Server not configured"},{status:500});
  const p=verify(cookies(req).ssb_session,secret);
  if(!p) return Response.json({authenticated:false},{status:401});
  const avatar_url=p.avatar
    ? `https://cdn.discordapp.com/avatars/${p.id}/${p.avatar}.png?size=128`
    : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(p.id)>>22n)%6}.png`;
  return Response.json({...p,avatar_url});
};

export const config = { path: "/auth/me" };
