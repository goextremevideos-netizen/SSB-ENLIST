import crypto from "node:crypto";

const CLIENT_ID = "1554957413889741011";
const REDIRECT_URI = "https://ssbenlist.netlify.app/auth/callback";
const HOME = "https://ssbenlist.netlify.app/";

function cookies(req) {
  const raw = req.headers.get("cookie") || "";
  return Object.fromEntries(raw.split(";").map(v => v.trim()).filter(Boolean).map(v => {
    const i=v.indexOf("="); return [v.slice(0,i), decodeURIComponent(v.slice(i+1))];
  }));
}
function b64url(s){ return Buffer.from(s).toString("base64url"); }
function sign(payload, secret){
  const body=b64url(JSON.stringify(payload));
  const sig=crypto.createHmac("sha256",secret).update(body).digest("base64url");
  return `${body}.${sig}`;
}

export default async (req) => {
  const secret = process.env.DISCORD_CLIENT_SECRET;
  if (!secret) return new Response("Missing DISCORD_CLIENT_SECRET in Netlify environment variables.", {status:500});

  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const savedState = cookies(req).ssb_oauth_state;
  if (!code || !state || !savedState || state !== savedState) {
    return Response.redirect(HOME+"?auth=error",302);
  }

  const body = new URLSearchParams({
    client_id: CLIENT_ID,
    client_secret: secret,
    grant_type: "authorization_code",
    code,
    redirect_uri: REDIRECT_URI
  });

  const tokenRes = await fetch("https://discord.com/api/v10/oauth2/token", {
    method:"POST",
    headers:{"Content-Type":"application/x-www-form-urlencoded"},
    body
  });
  if(!tokenRes.ok) return Response.redirect(HOME+"?auth=error",302);
  const token = await tokenRes.json();

  const userRes = await fetch("https://discord.com/api/v10/users/@me", {
    headers:{Authorization:`Bearer ${token.access_token}`}
  });
  if(!userRes.ok) return Response.redirect(HOME+"?auth=error",302);
  const u = await userRes.json();

  const payload = {
    id:u.id, username:u.username, global_name:u.global_name||null,
    avatar:u.avatar||null, exp:Date.now()+1000*60*60*8
  };
  const session=sign(payload,secret);

  return new Response(null,{
    status:302,
    headers:{
      Location:HOME,
      "Set-Cookie":`ssb_session=${session}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=28800`
    }
  });
};

export const config = { path: "/auth/callback" };
