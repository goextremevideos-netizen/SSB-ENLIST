SSB Enlistment Website — Discord Login Build

Already configured:
- Site: https://ssbenlist.netlify.app
- Discord Application ID: 1554957413889741011
- Discord redirect: https://ssbenlist.netlify.app/auth/callback
- Formspree: https://formspree.io/f/myezvljp

REQUIRED BEFORE DEPLOY:
1. In Netlify, open the ssbenlist site.
2. Go to Project configuration / Environment variables.
3. Add DISCORD_CLIENT_SECRET with the Client Secret from your Discord Developer Portal.
   Keep this secret only in Netlify. Never put it in index.html or share it publicly.
4. Redeploy this folder/ZIP to the SAME Netlify site.
5. Test Login with Discord.

The Netlify Functions securely exchange Discord's OAuth code server-side, fetch the verified
Discord identity, and expose only the verified username/ID to the application page.
