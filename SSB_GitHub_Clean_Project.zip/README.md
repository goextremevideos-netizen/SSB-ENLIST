# SSB Enlistment
Secure environment variables required in Netlify:
- DISCORD_CLIENT_SECRET
- DISCORD_WEBHOOK_URL

Never put either secret in GitHub.
